import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.jsx';
import './index.css';

// Component styles (same order as the original stylesheet)
import './components/Navbar.css';
import './components/Hero.css';
import './components/AppointmentCard.css';
import './components/Services.css';
import './components/Doctors.css';
import './components/DoctorSearch.css';
import './components/Footer.css';
import './components/Modal.css';

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <App />
  </StrictMode>
);

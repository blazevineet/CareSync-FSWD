// Base URLs of the CareSync microservices (running locally)
export const DOCTOR_API = 'http://localhost:8081/api/doctors';
export const USER_API = 'http://localhost:8082/api/users';

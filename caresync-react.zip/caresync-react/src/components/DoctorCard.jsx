export default function DoctorCard({ doctor, onViewProfile }) {
  return (
    <div className="doctor-card">
      <div className="doctor-image">🧑‍⚕️</div>

      <h3>{doctor.name}</h3>

      <p className="specialization">{doctor.specialization}</p>

      <p>
        ⭐ {doctor.rating} &nbsp; | &nbsp; {doctor.experienceYears}+ Years Experience
      </p>

      <button className="outline-btn profile-btn" onClick={() => onViewProfile(doctor)}>
        View Profile
      </button>
    </div>
  );
}

const NAV_LINKS = [
  { href: '#home', label: 'Home' },
  { href: '#doctors', label: 'Doctors' },
  { href: '#about', label: 'About' },
  { href: '#contact', label: 'Contact' },
];

export default function Navbar({ onLogin, onSignup }) {
  return (
    <div className="navbar">
      <div className="logo">
        Care<span>Sync</span>
      </div>

      <div className="nav-links">
        {NAV_LINKS.map((link) => (
          <a key={link.href} href={link.href}>
            {link.label}
          </a>
        ))}
      </div>

      <div className="nav-buttons">
        <button className="login-btn" onClick={onLogin}>Login</button>
        <button className="signup-btn" onClick={onSignup}>Sign Up</button>
      </div>
    </div>
  );
}

const QUICK_LINKS = ['Home', 'Doctors', 'About', 'Contact'];

export default function Footer() {
  return (
    <div className="footer" id="contact">
      <div>
        <h2>
          Care<span>Sync</span>
        </h2>
        <p>Making healthcare accessible, simple and convenient.</p>
      </div>

      <div>
        <h3>Quick Links</h3>
        {QUICK_LINKS.map((link) => (
          <p key={link}>{link}</p>
        ))}
      </div>

      <div>
        <h3>Contact</h3>
        <p>📧 support@caresync.com</p>
        <p>📞 +91 98765 43210</p>
      </div>
    </div>
  );
}

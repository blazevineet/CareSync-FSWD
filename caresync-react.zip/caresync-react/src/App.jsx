import { useCallback, useState } from 'react';
import useLocalStorage from './hooks/useLocalStorage';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Services from './components/Services';
import Doctors from './components/Doctors';
import Footer from './components/Footer';
import Modal from './components/Modal';
import LoginForm from './components/LoginForm';
import SignupForm from './components/SignupForm';
import AppointmentForm from './components/AppointmentForm';
import DoctorProfile from './components/DoctorProfile';

export default function App() {
  // Which modal is open: null or { type: 'login' | 'signup' | 'booking' | 'profile', doctor?, notice? }
  const [modal, setModal] = useState(null);
  const [appointments, setAppointments] = useLocalStorage('appointments', []);

  const closeModal = useCallback(() => setModal(null), []);
  const addAppointment = (appointment) => setAppointments((prev) => [...prev, appointment]);

  const doctorName = modal?.doctor?.name ?? 'Doctor';

  const titles = {
    login: 'Login',
    signup: 'Create Account',
    booking: `Book Appointment - ${doctorName}`,
    profile: 'Doctor Profile',
  };

  return (
    <>
      <Navbar
        onLogin={() => setModal({ type: 'login' })}
        onSignup={() => setModal({ type: 'signup' })}
      />
      <Hero onBookNow={() => setModal({ type: 'booking' })} />
      <Services />
      <Doctors onViewProfile={(doctor) => setModal({ type: 'profile', doctor })} />
      <Footer />

      {modal && (
        <Modal title={titles[modal.type]} onClose={closeModal}>
          {modal.type === 'login' && <LoginForm notice={modal.notice} onSuccess={closeModal} />}
          {modal.type === 'signup' && (
            <SignupForm
              onRegistered={() =>
                setModal({ type: 'login', notice: 'Account created successfully! Please log in.' })
              }
            />
          )}
          {modal.type === 'booking' && (
            <AppointmentForm
              doctorName={doctorName}
              onSave={addAppointment}
              onSuccess={closeModal}
            />
          )}
          {modal.type === 'profile' && (
            <DoctorProfile doctor={modal.doctor} onClose={closeModal} />
          )}
        </Modal>
      )}
    </>
  );
}
